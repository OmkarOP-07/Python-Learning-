# 8. Problem: Convert a list of words to uppercase using map()
# Statement: Given a list of words, convert them all to uppercase.

words = ["apple", "bannana", "guaVa"]
ans = list(map(lambda a: a.upper(),words))
print(ans)
