names = ["omkar", "hello", "apple", "cherry"]

list1 = list(filter(lambda a : a[0]=="a",names))

print(list1)